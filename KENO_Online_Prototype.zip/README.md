# KENO Online prototype

Ovo je Android prototip koji:
- traži Android dozvolu za plutajući prozor;
- traži korisničku MediaProjection dozvolu za snimanje ekrana;
- prikazuje plutajući, pomični pravac/liniju preko drugih aplikacija.

## Važno
Ovo je samo prototip overlay infrastrukture. Još NE prepoznaje automatski sto/kugle i NE računa stvarne putanje. Linija se ručno podešava povlačenjem dvije tačke. MediaProjection je inicijalizovan, ali obrada frejmova za detekciju nije implementirana.

## Build
GitHub Actions workflow je u `.github/workflows/android.yml`. Pokreni workflow ručno ili push na main, pa preuzmi artifact `KENO-debug-apk`.

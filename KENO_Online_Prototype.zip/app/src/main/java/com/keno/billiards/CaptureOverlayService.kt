package com.keno.billiards

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.Toast

class CaptureOverlayService : Service() {
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var windowManager: WindowManager? = null
    private var overlay: AimOverlay? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) { stopSelf(); return START_NOT_STICKY }
        createNotification()
        val code = intent.getIntExtra("resultCode", Activity.RESULT_CANCELED)
        val data = if (Build.VERSION.SDK_INT >= 33)
            intent.getParcelableExtra("resultData", Intent::class.java)
        else @Suppress("DEPRECATION") intent.getParcelableExtra("resultData")
        if (code != Activity.RESULT_OK || data == null) { stopSelf(); return START_NOT_STICKY }

        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, null)

        val metrics = resources.displayMetrics
        imageReader = ImageReader.newInstance(metrics.widthPixels, metrics.heightPixels, PixelFormat.RGBA_8888, 2)
        virtualDisplay = projection?.createVirtualDisplay(
            "KENO-screen-capture", metrics.widthPixels, metrics.heightPixels,
            metrics.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, null
        )
        showOverlay()
        return START_NOT_STICKY
    }

    private fun createNotification() {
        val channelId = "keno_capture"
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(channelId, "KENO screen analysis",
                NotificationManager.IMPORTANCE_LOW))
        }
        val notification = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, channelId)
        else Notification.Builder(this)
        startForeground(77, notification.setContentTitle("KENO aktivan")
            .setContentText("Overlay za testiranje je pokrenut.")
            .setSmallIcon(android.R.drawable.ic_menu_view).build())
    }

    private fun showOverlay() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        overlay = AimOverlay(this)
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        windowManager?.addView(overlay, params)
    }

    override fun onDestroy() {
        try { overlay?.let { windowManager?.removeView(it) } } catch (_: Exception) {}
        virtualDisplay?.release()
        imageReader?.close()
        projection?.stop()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private class AimOverlay(context: Context) : View(context) {
        private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.CYAN
            strokeWidth = 4f
            style = Paint.Style.STROKE
        }
        private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.YELLOW
            style = Paint.Style.FILL
        }
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 30f
            setShadowLayer(4f, 1f, 1f, Color.BLACK)
        }
        private var sx = 0.42f
        private var sy = 0.60f
        private var ex = 0.72f
        private var ey = 0.30f
        private var draggingStart = false

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat(); val h = height.toFloat()
            canvas.drawLine(sx*w, sy*h, ex*w, ey*h, linePaint)
            canvas.drawCircle(sx*w, sy*h, 11f, dotPaint)
            canvas.drawCircle(ex*w, ey*h, 8f, linePaint)
            canvas.drawText("KENO • povuci tačke za podešavanje", 24f, 48f, textPaint)
            canvas.drawText("Za gašenje: vrati se u KENO i pritisni Zaustavi", 24f, 88f, textPaint)
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            val x = event.x / width.coerceAtLeast(1)
            val y = event.y / height.coerceAtLeast(1)
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    draggingStart = distance(x, y, sx, sy) < distance(x, y, ex, ey)
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (draggingStart) { sx=x; sy=y } else { ex=x; ey=y }
                    invalidate(); return true
                }
                MotionEvent.ACTION_UP -> return true
            }
            return true
        }
        private fun distance(x: Float, y: Float, a: Float, b: Float) =
            (x-a)*(x-a) + (y-b)*(y-b)
    }
}
